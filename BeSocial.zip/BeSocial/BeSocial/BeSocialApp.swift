//
//  BeSocialApp.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import SwiftUI

@main
struct BeSocialApp: App {
    var body: some Scene {
        WindowGroup {
            //Unable to connect to network
//            FeedView(viewModel: FeedViewModel(networkManager: MockFeedsService()))

//            With network
            FeedView(viewModel: FeedViewModel(networkManager: FeedsService()))
        }
    }
}
