//
//  PostsViewModel.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import Foundation

protocol FeedViewModelProtocol {
    var posts: [Feed] {get set}
    var errorMessage: String { get set }
    var isLoading: Bool {get set}
    
    init(networkManager: PostServiceProtocol)
}

final class FeedViewModel: ObservableObject {
    @Published var posts: [Feed] = []
    @Published var errorMessage: String = ""
    @Published var isLoading: Bool = false

    private let postService: PostServiceProtocol

    init(networkManager: PostServiceProtocol) {
        postService = networkManager
    }

    func fetchPost() {
        isLoading = true

        Task {
            let result = try? await postService.fetchPost(endpoint: "db7a-7d13-4b50-a1d8")

            switch result {
            case .success(let posts):
                await handleResponse(posts: posts)
            case .failure(let error):
                await handleResponse(errorMessage: error.localizedDescription)
            case .none:
                await handleResponse(errorMessage: "Unknown error")
            }
        }
    }

    private func handleResponse(posts: [Feed]? = nil, errorMessage: String? = nil) async {
        await MainActor.run {
            if let posts {
                self.posts = posts
            }

            if let errorMessage {
                self.errorMessage = errorMessage
            }

            self.isLoading = false
        }
    }
}
