//
//  PostDetailViewModel.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import Foundation
import Combine

protocol PostDetailViewModelConfig {
    init(feed: Feed?)

    func getCommentsCount() -> Int
}

class PostDetailViewModel: ObservableObject, PostDetailViewModelConfig {
    @Published var feed: Feed?

    required init(feed: Feed?) {
        self.feed = feed
    }

    func getCommentsCount() -> Int {
        feed?.comments.count ?? 0
    }
}
