//
//  APIManager.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import Foundation

protocol NetworkRequestable {
    func request<T: Decodable>(type:T.Type, config: EndpointConfigurable) async throws -> Result<T, NetworkError>
}

enum NetworkError: Error {
    case invalidUrl
    case encodingError(String)
    case httpError(statusCode: Int)
    case decodingError(String)
    case networkError(String)
    case invalidPayload
    case noData
    case unknown
}

enum ContentType: String {
    case urlEncoded = "application/x-www-form-urlencoded"
    case json = "application/json; charset=utf-8"
}

enum HTTPMethod: String {
    case post = "POST"
    case get = "GET"
}

protocol EndpointConfigurable {
    var baseURL: String {get}
    var path: String {get}
    var httpMethod: HTTPMethod {get}
    var parameters: [String: Any] {get}
    func urlRequest() throws -> URLRequest
}

class NetworkManager: NetworkRequestable {
    static let shared: NetworkManager = NetworkManager()

    private init() {}

    func request<T: Decodable>(type:T.Type, config: EndpointConfigurable) async throws -> Result<T, NetworkError> {
        let urlRequest = try config.urlRequest()

        let (data, response) = try await URLSession.shared.data(for: urlRequest)
        
        if let httpRes = response as? HTTPURLResponse {
            guard (200..<300).contains(httpRes.statusCode) else {
                return .failure(NetworkError.httpError(statusCode: httpRes.statusCode))
            }
        }

        guard !data.isEmpty else {
            return .failure(NetworkError.noData)
        }

        do {
            let decodedResponse = try JSONDecoder().decode(T.self, from: data)
            return .success(decodedResponse)
        }
        catch {
            return .failure(NetworkError.decodingError(error.localizedDescription))
        }
    }

}
