//
//  ImageCache.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import Foundation
import UIKit

actor ImageCache {
    static let shared = ImageCache()
    private var cache: [String: UIImage] = [:]

    func getImage(forKey key: String) -> UIImage? {
        return cache[key]
    }

    func saveImage(_ image: UIImage, forKey key: String) {
        cache[key] = image
    }
}
