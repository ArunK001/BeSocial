//
//  ImageLoader.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import Foundation
import UIKit

final class ImageLoader {
    static let shared = ImageLoader()

    private init() {}

    func loadImage(from urlString: String) async throws -> UIImage {
        // Check the cache first
        if let cachedImage = await ImageCache.shared.getImage(forKey: urlString) {
            return cachedImage
        }

        // Download the image
        guard let url = URL(string: urlString) else {
            throw URLError(.badURL)
        }
        let (data, _) = try await URLSession.shared.data(from: url)
        guard let image = UIImage(data: data) else {
            throw URLError(.cannotDecodeContentData)
        }

        // Cache the image
        await ImageCache.shared.saveImage(image, forKey: urlString)
        return image
    }
}
