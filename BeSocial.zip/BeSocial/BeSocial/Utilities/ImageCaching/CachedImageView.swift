//
//  CachedImageView.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import SwiftUI

struct CachedImageView: View {
    let urlString: String
    let placeholder: Image

    @State private var image: UIImage? = nil
    @State private var isLoading = true

    var body: some View {
        Group {
            if let image = image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
            } else if isLoading || image == nil {
                placeholder
                    .resizable()
                    .scaledToFit()
                    .opacity(0.3)
            }
        }
        .task {
            await loadImage()
        }
    }

    @MainActor
    private func loadImage() async {
        do {
            let loadedImage = try await ImageLoader.shared.loadImage(from: urlString)
            image = loadedImage
            isLoading = false
        } catch {
            isLoading = false
        }
    }
}
    
