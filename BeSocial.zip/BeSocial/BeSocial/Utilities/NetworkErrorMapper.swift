//
//  NetworkErrorMapper.swoft.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import Foundation

struct NetworkErrorMapper {
    static func mapErrorToMessage(_ error: NetworkError) -> String {
        switch error {
        case .invalidUrl:
            return "Invalid URL"
        case .decodingError(_), .encodingError(_):
            return "Encoding/Decoding error"
        case .httpError(_):
            return "Network error"
        case .unknown:
            return "Unknown"
        default:
            return "Something went wrong"
        }
    }
}
