//
//  Post.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import Foundation

struct Feed: Codable, Identifiable {
    var id = UUID()

    let user: String
    let photos: [String]
    let title: String
    let likes: Int
    var comments: [Comment]
    let geoTag: GeoTag?
    let following: Bool

    enum CodingKeys: String, CodingKey {
        case user
        case photos
        case title
        case likes
        case comments
        case geoTag = "geo_tag"
        case following
    }
}

struct Comment: Codable, Identifiable {
    var id = UUID()

    var comment: String
    var likes: Int

    enum CodingKeys: String, CodingKey {
        case comment
        case likes
    }
}

struct GeoTag: Codable {
    let latitude: Double
    let longitude: Double
    let location: String
}
