//
//  PostService.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import Foundation

protocol PostServiceProtocol {
    func fetchPost(endpoint: String) async throws-> Result<[Feed], NetworkError>
}

enum FeedEndpoint: EndpointConfigurable {
    case feeds(HTTPMethod, String, [String: Any])

    // Base URL
    var baseURL: String {
        "https://dummyjson.com/"
    }

    // Path for the endpoint
    var path: String {
        switch self {
        case .feeds(_, let path, _):
            return "c/\(path)"
        }
    }

    // HTTP method (GET, POST, etc.)
    var httpMethod: HTTPMethod {
        switch self {
        case .feeds(let method, _, _):
            return method
        }
    }

    // Parameters for the request
    var parameters: [String: Any] {
        switch self {
        case .feeds(_, _, let params):
            return params
        }
    }

    // Construct URLRequest
    func urlRequest() throws -> URLRequest {
        guard let url = URL(string: baseURL + path) else {
            throw NetworkError.invalidUrl
        }

        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = httpMethod.rawValue
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")

        if httpMethod == .post {
            do {
                let jsonData = try JSONSerialization.data(withJSONObject: parameters, options: [])
                urlRequest.httpBody = jsonData
            } catch {
                throw NetworkError.invalidPayload
            }
        }

        return urlRequest
    }
}


struct FeedsService: PostServiceProtocol {
    private let networkManager = NetworkManager.shared

    func fetchPost(endpoint: String) async throws-> Result<[Feed], NetworkError> {
        let endpointConfiguration = FeedEndpoint.feeds(.get, endpoint, [:])
        let result = try await networkManager.request(type: [Feed].self,config: endpointConfiguration)

        return result
    }
}

struct MockFeedsService: PostServiceProtocol {
    func fetchPost(endpoint: String) async throws-> Result<[Feed], NetworkError> {
        guard let mockData = mockPosts.data(using: .utf8), !mockData.isEmpty else {
            return .failure(NetworkError.invalidUrl)
        }

        do {
            let decoder = JSONDecoder()
            let post = try decoder.decode([Feed].self, from: mockData)
            return .success(post)
        }
        catch {
            return .failure(NetworkError.noData)
        }
    }
}
