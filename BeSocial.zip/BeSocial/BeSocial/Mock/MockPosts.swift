//
//  MockPosts.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

let mockPosts = """
[
  {
    "user": "john_doe",
    "photos": [
      "https://images.unsplash.com/photo-1609741199695-096c491c7ccc?q=80&w=3027&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      "https://images.unsplash.com/photo-1609741199695-096c491c7ccc?q=80&w=3027&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
    ],
    "title": "Exploring the mountains ൾ 🌄",
    "likes": 154,
    "comments": [
      {
        "comment": "Amazing view!",
        "likes": 32
      },
      {
        "comment": "Wish I was there.",
        "likes": 25
      },
      {
        "comment": "This place looks surreal.",
        "likes": 19
      }
    ],
    "geo_tag": {
      "latitude": 37.7749,
      "longitude": -122.4194,
      "location": "San Francisco, CA"
    },
    "following": false
  },
  {
    "user": "jane_smith",
    "photos": [
      "https://images.unsplash.com/photo-1642049671748-2e35cdb11c2c?q=80&w=2912&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      "https://images.unsplash.com/photo-1566577134657-a8b2da3b4dcb?q=80&w=2940&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      "https://images.unsplash.com/photo-1686397141317-4f470cbc5dbb?q=80&w=2787&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
    ],
    "title": "Coffee time with friends",
    "likes": 120,
    "comments": [
      {
        "comment": "Looks delicious!",
        "likes": 40
      },
      {
        "comment": "I love coffee!",
        "likes": 28
      },
      {
        "comment": "Miss you guys!",
        "likes": 15
      },
      {
        "comment": "Miss you guys!",
        "likes": 15
      },
      {
        "comment": "Hello world 👍🏻!",
        "likes": 15
      },
      {
        "comment": "Miss you guys!",
        "likes": 15
      },
{
        "comment": "Miss you guys! ❤️",
        "likes": 15
      }
    ],
    "following": true
  },
  {
    "user": "mike_williams",
    "photos": [
      "https://images.unsplash.com/photo-1582127572855-52d2100d4ebd?q=80&w=2776&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      "https://images.unsplash.com/photo-1535356795203-50b2eb73f96c?q=80&w=2394&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
    ],
    "title": "Sunset vibes",
    "likes": 200,
    "comments": [
      {
        "comment": "The colors are so vibrant!",
        "likes": 50
      },
      {
        "comment": "Nature at its best.",
        "likes": 35
      },
      {
        "comment": "Wish I was there to see it.",
        "likes": 25
      }
    ],
    "geo_tag": {
      "latitude": 34.0522,
      "longitude": -118.2437,
      "location": "Los Angeles, CA"
    },
    "following": false
  },
  {
    "user": "emily_davis",
    "photos": [
      "https://unsplash.com/photos/a-close-up-of-a-rope-on-a-boat-8gW-2lhPC4s"
    ],
    "title": "Beach day fun",
    "likes": 95,
    "comments": [
      {
        "comment": "Looks like a perfect day!",
        "likes": 30
      },
      {
        "comment": "I need a vacation!",
        "likes": 22
      },
      {
        "comment": "Such a beautiful beach.",
        "likes": 18
      }
    ],
    "following": true
  },
  {
    "user": "Subrahmania Venkat",
    "photos": [
      "https://unsplash.com/photos/man-in-black-zip-up-jacket-wearing-black-framed-eyeglasses-FuOl4EMwQeg",
      "https://unsplash.com/photos/aerial-view-of-city-buildings-during-daytime-3vMMoSFdWb4"
    ],
    "title": "Bengaluru Palace: Bengaluru Palace is a 19th c..",
    "likes": 75,
    "comments": [
      {
        "comment": "it's amazing!",
        "likes": 28
      },
      {
        "comment": "Can you share the name?",
        "likes": 18
      },
      {
        "comment": "So pretty!",
        "likes": 12
      },
        {
          "comment": "Bengaluru Palace is a 19th century royal palace located in Bengaluru, Karnataka, India, built in an area that was owned by the Rev. John Garrett, the first principal of the Central High School in Bangalore.",
        "likes": 46
        }
    ],
    "geo_tag": {
      "latitude": 13.0035,
      "longitude": 77.5891,
      "location": "Bengaluru, IN"
    },
    "following": false
  },
  {
    "user": "luke_king",
    "photos": [
      "https://unsplash.com/photos/city-during-night-0zbpC3FDU-8",
      "https://unsplash.com/photos/birds-eye-view-of-white-boat-on-body-of-water-JT0ryoeeoYI"
    ],
    "title": "City skyline at night",
    "likes": 230,
    "comments": [
      {
        "comment": "The lights are amazing!",
        "likes": 60
      },
      {
        "comment": "I love cityscapes.",
        "likes": 45
      },
      {
        "comment": "Such a peaceful view.",
        "likes": 20
      }
    ],
    "geo_tag": {
      "latitude": 51.5074,
      "longitude": -0.1278,
      "location": "London, UK"
    },
    "following": true
  },
  {
    "user": "olivia_martin",
    "photos": [
      "https://w0.peakpx.com/wallpaper/176/142/HD-wallpaper-neon-design-green-leaves-leaves-nature-neon-lights.jpg",
      "https://unsplash.com/photos/a-woman-hiking-up-a-trail-in-the-mountains-lGsSjuLEo5k"
    ],
    "title": "Delicious homemade pizza",
    "likes": 180,
    "comments": [
      {
        "comment": "Can you share the recipe?",
        "likes": 50
      },
      {
        "comment": "I need this in my life!",
        "likes": 40
      },
      {
        "comment": "Looks so cheesy!",
        "likes": 30
      }
    ],
    "following": false
  },
  {
    "user": "chris_lee",
    "photos": [
      "https://w0.peakpx.com/wallpaper/884/50/HD-wallpaper-golden-autumn-fall-autumn-golden-colors-birch-yellow-trees-birch-trees-safron-tree-leaves-green-color.jpg",
      "https://unsplash.com/photos/aerial-view-of-the-ocean-with-rocks-and-water-Ii6dNZIuRg0"
    ],
    "title": "Camping under the stars",
    "likes": 140,
    "comments": [
      {
        "comment": "Sounds like the perfect night.",
        "likes": 35
      },
      {
        "comment": "I love camping!",
        "likes": 25
      },
      {
        "comment": "Such a serene view.",
        "likes": 20
      }
    ],
    "geo_tag": {
      "latitude": 42.4072,
      "longitude": -71.3824,
      "location": "Boston, MA"
    },
    "following": false
  },
  {
    "user": "ava_taylor",
    "photos": [
      "https://w0.peakpx.com/wallpaper/222/878/HD-wallpaper-full-black-screen-waterdrops-on-feather.jpg",
      "https://unsplash.com/photos/aerial-view-of-city-buildings-during-night-time-w_YpHggpgDE"
    ],
    "title": "Winter wonderland",
    "likes": 160,
    "comments": [
      {
        "comment": "This is magical!",
        "likes": 45
      },
      {
        "comment": "I want to go there!",
        "likes": 35
      },
      {
        "comment": "Snow looks so pure.",
        "likes": 25
      }
    ],
    "following": true
  },
  {
    "user": "benjamin_walker",
    "photos": [
      "https://w0.peakpx.com/wallpaper/554/261/HD-wallpaper-super-amoled-black-amoled-display-amoled-amoled-app-amoled-best-amoled-black-amoled-black-dark-super-amoled.jpg",
      "https://unsplash.com/photos/a-toy-girl-holding-a-sign-tuB0FETbHfw"
    ],
    "title": "Street art exploration",
    "likes": 110,
    "comments": [
      {
        "comment": "Such vibrant colors!",
        "likes": 40
      },
      {
        "comment": "Where is this located?",
        "likes": 30
      },
      {
        "comment": "Art in the streets is awesome.",
        "likes": 20
      }
    ],
    "following": false
  },
  {
    "user": "mia_johnson",
    "photos": [
      "https://unsplash.com/photos/aerial-view-of-city-buildings-during-daytime-3vMMoSFdWb4",
      "https://unsplash.com/photos/a-close-up-of-a-rope-on-a-boat-8gW-2lhPC4s"
    ],
    "title": "The beauty of spring",
    "likes": 130,
    "comments": [
      {
        "comment": "This looks like a perfect spring day.",
        "likes": 40
      },
      {
        "comment": "I can almost smell the flowers.",
        "likes": 35
      },
      {
        "comment": "Such a lovely scene.",
        "likes": 20
      }
    ],
    "following": true
  },
  {
    "user": "jackson_moore",
    "photos": [
      "https://unsplash.com/photos/aerial-view-of-city-buildings-during-night-time-w_YpHggpgDE"
    ],
    "title": "Weekend adventure",
    "likes": 90,
    "comments": [
      {
        "comment": "Looks like a fun trip!",
        "likes": 30
      },
      {
        "comment": "Where is this?",
        "likes": 20
      },
      {
        "comment": "I need an adventure like this!",
        "likes": 15
      }
    ],
    "following": false
  },
  {
    "user": "lucas_brown",
    "photos": [
      "https://unsplash.com/photos/aerial-photography-of-high-rise-buildings-geq6njOQ1Ew",
      "https://unsplash.com/photos/a-white-antenna-with-many-small-balls-COFXWa6LJdw"
    ],
    "title": "Skyscraper views",
    "likes": 180,
    "comments": [
      {
        "comment": "This is breathtaking!",
        "likes": 60
      },
      {
        "comment": "I love the view from above.",
        "likes": 35
      },
      {
        "comment": "The contrast is amazing.",
        "likes": 22
      }
    ],
    "following": true
  },
  {
    "user": "grace_wilson",
    "photos": [
      "https://unsplash.com/photos/a-banana-sits-on-a-bench-xhUKJE8_w7o",
      "https://unsplash.com/photos/aerial-photo-of-buildings-g-Z4_2nnXcc"
    ],
    "title": "Delightful picnic",
    "likes": 142,
    "comments": [
      {
        "comment": "This looks like the best day.",
        "likes": 50
      },
      {
        "comment": "I want to join!",
        "likes": 30
      },
      {
        "comment": "That banana is perfectly placed.",
        "likes": 20
      }
    ],
    "following": false
  },
  {
    "user": "ella_thompson",
    "photos": [
      "https://unsplash.com/photos/selective-focus-photography-of-silver-colored-chain-during-daytime-k-Ff5sB4iCY",
      "https://unsplash.com/photos/a-close-up-of-a-rope-on-a-boat-8gW-2lhPC4s"
    ],
    "title": "Morning on the lake",
    "likes": 167,
    "comments": [
      {
        "comment": "The water looks so calm.",
        "likes": 45
      },
      {
        "comment": "Wish I could be there.",
        "likes": 35
      },
      {
        "comment": "Perfect way to start the day.",
        "likes": 25
      }
    ],
    "following": true
  },
  {
    "user": "lucy_moore",
    "photos": [
      "https://unsplash.com/photos/aerial-photo-of-buildings-g-Z4_2nnXcc",
      "https://unsplash.com/photos/a-cell-phone-tower-with-a-lot-of-antennas-on-top-of-it-Nl9MyCD1_a4"
    ],
    "title": "Space exploration vibes",
    "likes": 190,
    "comments": [
      {
        "comment": "This reminds me of space tech.",
        "likes": 60
      },
      {
        "comment": "I need this shot for my collection.",
        "likes": 30
      },
      {
        "comment": "So futuristic.",
        "likes": 25
      }
    ],
    "following": false
  },
  {
    "user": "jackson_brooks",
    "photos": [
      "https://unsplash.com/photos/assorted-color-anime-character-figurines-MAqmEdUCq4k",
      "https://unsplash.com/photos/aerial-view-of-the-ocean-with-rocks-and-water-Ii6dNZIuRg0"
    ],
    "title": "Anime collectibles",
    "likes": 220,
    "comments": [
      {
        "comment": "These look amazing!",
        "likes": 60
      },
      {
        "comment": "I want to start a collection like this.",
        "likes": 40
      },
      {
        "comment": "Which one is your favorite?",
        "likes": 25
      }
    ],
    "following": false
  },
  {
    "user": "hannah_miller",
    "photos": [
      "https://unsplash.com/photos/aerial-view-of-city-buildings-during-daytime-3vMMoSFdWb4",
      "https://unsplash.com/photos/a-cell-phone-tower-with-a-lot-of-antennas-on-top-of-it-Nl9MyCD1_a4"
    ],
    "title": "Cloudy afternoon",
    "likes": 210,
    "comments": [
      {
        "comment": "Looks so peaceful.",
        "likes": 50
      },
      {
        "comment": "I love a cloudy day.",
        "likes": 35
      },
      {
        "comment": "Such a beautiful view.",
        "likes": 30
      }
    ],
    "following": true
  },
  {
    "user": "liam_wilson",
    "photos": [
      "https://unsplash.com/photos/a-view-of-the-wing-of-an-airplane-through-a-window-feexj8sv1DM",
      "https://unsplash.com/photos/aerial-view-of-city-buildings-during-night-time-w_YpHggpgDE"
    ],
    "title": "Sky-high travel",
    "likes": 250,
    "comments": [
      {
        "comment": "That view is amazing!",
        "likes": 70
      },
      {
        "comment": "I need to travel more.",
        "likes": 40
      },
      {
        "comment": "Flying is such an adventure.",
        "likes": 25
      }
    ],
    "following": false
  },
  {
    "user": "charlotte_james",
    "photos": [
      "https://unsplash.com/photos/an-aerial-view-of-a-body-of-water-hWBU3vMpTkg",
      "https://unsplash.com/photos/blue-net-IV--3UEiHlI"
    ],
    "title": "Ocean vibes",
    "likes": 235,
    "comments": [
      {
        "comment": "This is so calming.",
        "likes": 60
      },
      {
        "comment": "I can listen to the ocean.",
        "likes": 40
      },
      {
        "comment": "Perfectly captured!",
        "likes": 30
      }
    ],
    "following": true
  },
  {
    "user": "ella_clark",
    "photos": [
      "https://unsplash.com/photos/aerial-photo-of-buildings-g-Z4_2nnXcc",
      "https://unsplash.com/photos/a-toy-girl-holding-a-sign-tuB0FETbHfw"
    ],
    "title": "Street food delights",
    "likes": 175,
    "comments": [
      {
        "comment": "Can I get the recipe? This looks mouth-watering! So many flavors!",
        "likes": 45
      }
    ],
    "following": false
  }
]
"""
