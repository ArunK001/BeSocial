//
//  PostView.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import SwiftUI

struct PostView: View {
    @Binding var feed: Feed
    @EnvironmentObject var navigateData: NavigationData

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            PostHeaderView(feed: $feed)
                .buttonStyle(.borderless)
                .environmentObject(navigateData)

            PostImageView(postImage: feed.photos)
                .clipShape(
                    .rect(
                        bottomLeadingRadius: 10,
                        bottomTrailingRadius: 10,
                        topTrailingRadius: 10
                    )
                )
                .overlay(content: {
                    Rectangle()
                    .stroke(.gray, lineWidth: 1)
                })
                .onTapGesture {
                    navigateData.selectedFeed = feed
                    navigateData.navigateToDetail = true
                }

            PostFooterView(feed: feed)
                .frame(maxWidth: .infinity)
        }
    }
}

#Preview {
    PostView(feed: .constant(Feed(user: "", photos: [""], title: "", likes: 12, comments: [Comment(comment: "", likes: 213)], geoTag: GeoTag(latitude: 12.0, longitude: 71.0, location: "Area 7"), following: false)))
        .environmentObject(NavigationData())
}
