//
//  PostImageView.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import SwiftUI

struct PostImageView: View {
    let postImage: [String]

    var body: some View {
        TabView {
            ForEach(postImage, id: \.self) { photo in
                CachedImageView(
                    urlString: photo,
                    placeholder: Image(systemName: "questionmark.diamond")
                )
                .scaledToFill()
                .accessibilityIdentifier("homeTab")
            }
        }
        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .always))
        .foregroundColor(.gray)
        .frame(height: 400)
    }
}

#Preview {
    PostImageView(postImage: [""])
}
