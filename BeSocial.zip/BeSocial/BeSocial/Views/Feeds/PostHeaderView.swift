//
//  PostHeaderView.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import SwiftUI

struct PostHeaderView: View {
    @Binding var feed: Feed

    @EnvironmentObject var navigateData: NavigationData

    var body: some View {
        HStack(alignment: .top) {
            Image("ProfileIconPlaceHolder")
                .resizable()
                .scaledToFill()
                .frame(width: 40, height: 40)

            VStack(alignment: .leading) {
                Text(feed.user)
                    .font(.title)

                if let location = feed.geoTag?.location {
                    Button(location){
                        navigateData.selectedFeed = feed
                        navigateData.navigateToMaps = true
                    }
                    .font(.subheadline)
                    .padding(.bottom)
                }
            }

            Spacer()
        }
    }
}

#Preview {
    PostHeaderView(feed: .constant(Feed(user: "",
                                        photos: [""],
                                        title: "",
                                        likes: 12,
                                        comments: [Comment(comment: "", likes: 213)],
                                        geoTag: GeoTag(latitude: 12.0, longitude: 71.0, location: "Area 7"),
                                        following: false)))
        .environmentObject(NavigationData())
}
