//
//  PostView.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import SwiftUI

class NavigationData: ObservableObject {
    @Published var navigateToMaps = false
    @Published var navigateToDetail = false
    @Published var selectedFeed: Feed?
}

struct FeedView: View {
    @StateObject private var viewModel: FeedViewModel
    @StateObject private var navigationData = NavigationData()

    init(viewModel: FeedViewModel) {
        _viewModel = StateObject(wrappedValue: viewModel)
    }

    var body: some View {
        NavigationStack {
            VStack {
                if viewModel.isLoading {
                    ProgressView("Loading..")
                        .padding()
                }
                else if !viewModel.errorMessage.isEmpty {
                    Text(viewModel.errorMessage)
                        .foregroundColor(.red)
                        .padding()
                }
                else {
                    List(viewModel.posts, id: \.id) { feed in
                        PostView(feed: .constant(feed))

                            .listRowSeparator(.hidden)
                            .listRowBackground(Color.clear)
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("BeSocial")
            .navigationDestination(isPresented: $navigationData.navigateToMaps) {
                //Using Environment Object to Pass data
                LazyView {
                    MapView()
                        .environmentObject(navigationData)
                }
            }
            .navigationDestination(isPresented: $navigationData.navigateToDetail, destination: {
                //Using binding
                LazyView {
                    PostDetail(viewModel: PostDetailViewModel(feed: navigationData.selectedFeed))
                }
            })
            .environmentObject(navigationData)
        }
        .onAppear{
            viewModel.fetchPost()
        }
    }
}

struct LazyView<Content: View>: View {
    let build: () -> Content

    init(build: @escaping () -> Content) {
        self.build = build
    }

    var body: some View {
        build()
    }
}

#Preview {
    FeedView(viewModel: FeedViewModel(networkManager: MockFeedsService()))
}
