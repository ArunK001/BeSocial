//
//  PostFooter.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import SwiftUI

struct PostFooterView: View {
    @State var feed: Feed
    @State var liked: Bool = false

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 10) {
                Text(feed.title)
                    .font(.headline)

                HStack(spacing: 10){
                    Button(action: {
                    }, label: {
                        HStack {
                            Image(systemName: "heart.fill")

                            Text("\(feed.likes)")
                                .font(.subheadline)
                        }
                    })
                    .foregroundColor(.black)
                }

                if let firstComment = feed.comments.first {
                    Text(firstComment.comment)
                        .font(.body)
                        .foregroundColor(.gray)
                }
            }

            Spacer()
        }
        .frame(maxWidth: .infinity)
    }
}

#Preview {
    PostFooterView(feed: Feed(user: "Test", photos: [""], title: "New Photo", likes: 234, comments: [Comment(comment: "One Comment", likes: 3)], geoTag: nil, following: false))
}
