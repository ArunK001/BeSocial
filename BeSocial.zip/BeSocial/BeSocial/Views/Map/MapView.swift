//
//  MapView.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import SwiftUI
import MapKit

struct MapView: View {
    @EnvironmentObject var navigationData: NavigationData
    @State private var region: MKCoordinateRegion

    init() {
        let initialCenter = CLLocationCoordinate2D(latitude: 12.0, longitude: 77.0)

        _region = State(initialValue: MKCoordinateRegion(
            center: initialCenter,
            span: MKCoordinateSpan(latitudeDelta: 0.8, longitudeDelta: 0.8)
        ))
    }

    var body: some View {
        Map {
            let title = navigationData.selectedFeed?.title ?? ""
            Marker(title, coordinate: region.center)

            Annotation(title, coordinate: region.center) {
                ZStack {
                    RoundedRectangle(cornerRadius: 5)
                        .fill(Color.teal)
                }
            }
        }
        .navigationTitle(navigationData.selectedFeed?.title ?? "")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            updateRegion()
        }
    }

    private func updateRegion() {
        region.center = CLLocationCoordinate2D(latitude: navigationData.selectedFeed?.geoTag?.latitude ?? 0.0,
                                               longitude: navigationData.selectedFeed?.geoTag?.longitude ?? 0.0)
    }
}

#Preview {
    MapView()
}
