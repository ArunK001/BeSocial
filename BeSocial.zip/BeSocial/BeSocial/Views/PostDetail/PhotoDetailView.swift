//
//  PhotoDetailView.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import SwiftUI

struct PhotoDetailView: View {
    @Binding var photos: [String]

    var body: some View {
        ForEach(photos, id: \.self) { url in
            VStack {
                AsyncImage(url: URL(string: url)) { phase in
                    if let image = phase.image {
                        image.resizable()
                            .scaledToFit()
                            .frame(height: 400)
                    }
                    else if phase.error != nil || phase.image == nil {
                        Image(systemName: "questionmark.diamond")
                            .resizable()
                            .aspectRatio(1,contentMode: .fit)
                            .frame(height: 400)
                    }
                    else {
                        ZStack{
                            Image(systemName: "photo.fill")
                                .resizable()
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                            ProgressView()
                        }
                    }
                }
            }
            .listRowSeparator(.hidden)
            .background(Color.secondary.opacity(0.2))
            .cornerRadius(4)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}
