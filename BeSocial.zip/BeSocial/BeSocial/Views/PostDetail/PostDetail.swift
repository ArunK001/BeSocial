//
//  PostDetail.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import SwiftUI

protocol PostDetailConfig {
    init(viewModel: PostDetailViewModel)
}

struct PostDetail: View {
    @StateObject private var viewModel: PostDetailViewModel

    init(viewModel: PostDetailViewModel) {
        _viewModel = StateObject(wrappedValue: viewModel)
    }

    var body: some View {
        VStack {
            HStack {
                Image("ProfileIconPlaceHolder")
                    .resizable()
                    .frame(width: 40, height: 40)

                VStack(alignment: .leading) {
                    Text(viewModel.feed?.user ?? "")
                        .font(.title)
                    Text(viewModel.feed?.title ?? "")
                        .font(.subheadline)
                }

                Spacer()
            }
            .padding()
            .border(Color.gray)
            .padding()

            Spacer()

            List {
                PhotoDetailView(photos: Binding(get: {
                    viewModel.feed?.photos ?? []
                }, set: {_ in
                }))

                Section(header: HStack {
                    Image(systemName: "message")
                        .resizable()
                        .frame(width: 20, height: 20)

                    Text(viewModel.getCommentsCount() > 1 ? "Comments" : "Comment")
                }) {
                    PhotoCommentsView(comments: Binding(get: {
                        viewModel.feed?.comments ?? []
                    }, set: {
                        viewModel.feed?.comments = $0
                    }))
                }
            }
            .listStyle(.plain)

        }
    }
}
