//
//  PhotoCommentsView.swift
//  BeSocial
//
//  Created by Arun Pattanayak on 04/12/24.
//

import SwiftUI

struct PhotoCommentsView: View {
    @Binding var comments: [Comment]

    var body: some View {
        VStack(alignment: .leading) {
            ForEach($comments , id: \.id) { $commentDetail in
                HStack(alignment: .top) {
                    Text("\(commentDetail.comment)")

                    Spacer()

                    LikeView(likes: $commentDetail.likes)
                }
                .padding(.bottom, 10)
            }
        }
        .listRowSeparator(.hidden)
    }
}


struct LikeView: View {
    @Binding var likes: Int

    var body: some View {
        Image(systemName: likes%2 == 0 ?  "hand.thumbsup.fill" : "hand.thumbsup")
        Text("\(likes)")
    }
}
