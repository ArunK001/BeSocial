//
//  BeSocialUITests.swift
//  BeSocialUITests
//
//  Created by Arun Pattanayak on 04/12/24.
//


import XCTest

final class BeSocialUITests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.

        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false

        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    @MainActor
    func testExample() throws {
        // UI tests must launch the application that they test.
        let app = XCUIApplication()
        app.launch()
        
    }
    
    @MainActor
    func testScroll() {
        let app = XCUIApplication()
        app.launch()
        
        let firstItem = app.staticTexts["BeSocial"]
        XCTAssertTrue(firstItem.exists, "Header visible")
        
        let listItem = app.collectionViews.firstMatch
        XCTAssertTrue(listItem.exists, "Header visible")
        
        for _ in 1...2 {
            listItem.swipeUp()
        }
        
        XCTAssertTrue(listItem.staticTexts["emily_davis"].exists, "Title exists")
    }
    
    func testTap() {
        let app = XCUIApplication()
        app.launch()
        
        let collectionViewsQuery = app.collectionViews
        collectionViewsQuery/*@START_MENU_TOKEN@*/.buttons["San Francisco, CA"]/*[[".cells.buttons[\"San Francisco, CA\"]",".buttons[\"San Francisco, CA\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        app.navigationBars["Exploring the mountains ൾ 🌄"].buttons["BeSocial"].tap()

        let hometabImage = collectionViewsQuery.cells.collectionViews.containing(.other, identifier:"Vertical scroll bar, 2 pages")/*@START_MENU_TOKEN@*/.images["homeTab"]/*[[".cells.images[\"homeTab\"]",".images[\"homeTab\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/
        hometabImage.tap()

        let element = collectionViewsQuery.children(matching: .cell).element(boundBy: 0).children(matching: .other).element(boundBy: 1).children(matching: .other).element.children(matching: .other).element
        element.swipeUp()
        element.swipeUp()
        app.navigationBars["_TtGC7SwiftUI32NavigationStackHosting"].buttons["BeSocial"].tap()
        hometabImage.swipeLeft()
    }
    
    func testScrollAndSeeLocation() {
        let app = XCUIApplication()
        app.launch()
        
        let collectionViewsQuery = app.collectionViews
        let verticalScrollBar2PagesCollectionViewsQuery = collectionViewsQuery.cells.collectionViews.containing(.other, identifier:"Vertical scroll bar, 2 pages")
        let hometabImage = verticalScrollBar2PagesCollectionViewsQuery/*@START_MENU_TOKEN@*/.images["homeTab"]/*[[".cells.images[\"homeTab\"]",".images[\"homeTab\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/
        collectionViewsQuery.firstMatch.swipeUp()
        collectionViewsQuery.firstMatch.swipeUp()
        verticalScrollBar2PagesCollectionViewsQuery/*@START_MENU_TOKEN@*/.images["homeTab"]/*[[".cells",".images[\"Question\"]",".images[\"homeTab\"]"],[[[-1,2],[-1,1],[-1,0,1]],[[-1,2],[-1,1]]],[0]]@END_MENU_TOKEN@*/.swipeUp()
        collectionViewsQuery.staticTexts["Subrahmania Venkat"].tap()
        
        let cell = app.collectionViews.containing(.other, identifier:"Vertical scroll bar, 16 pages").children(matching: .cell).element(boundBy: 1)
        
        XCTAssertNotNil(cell)
        
        collectionViewsQuery/*@START_MENU_TOKEN@*/.buttons["Bengaluru, IN"]/*[[".cells.buttons[\"Bengaluru, IN\"]",".buttons[\"Bengaluru, IN\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        app.navigationBars["Bengaluru Palace: Bengaluru Palace is a 19th c.."].buttons["BeSocial"].tap()
        
    }
    
    func testScrollAndCheckPost() {
        let app = XCUIApplication()
        app.launch()
        
        let collectionViewsQuery = app.collectionViews
        let verticalScrollBar2PagesCollectionViewsQuery = collectionViewsQuery.cells.collectionViews.containing(.other, identifier:"Vertical scroll bar, 2 pages")
        collectionViewsQuery.firstMatch.swipeUp()
        collectionViewsQuery.firstMatch.swipeUp()
        verticalScrollBar2PagesCollectionViewsQuery/*@START_MENU_TOKEN@*/.images["homeTab"]/*[[".cells",".images[\"Question\"]",".images[\"homeTab\"]"],[[[-1,2],[-1,1],[-1,0,1]],[[-1,2],[-1,1]]],[0]]@END_MENU_TOKEN@*/.swipeUp()
        collectionViewsQuery.staticTexts["Subrahmania Venkat"].tap()
        
        let cell = app.collectionViews.containing(.other, identifier:"Vertical scroll bar, 16 pages").children(matching: .cell).element(boundBy: 1)
        
        XCTAssertNotNil(cell)
        
        collectionViewsQuery.cells.collectionViews.containing(.other, identifier:"Vertical scroll bar, 2 pages")/*@START_MENU_TOKEN@*/.images["homeTab"]/*[[".cells.images[\"homeTab\"]",".images[\"homeTab\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        collectionViewsQuery.children(matching: .cell).element(boundBy: 0).children(matching: .other).element(boundBy: 1).children(matching: .other).element.children(matching: .other).element.swipeUp()
        
        let besocialButton = app.navigationBars["_TtGC7SwiftUI32NavigationStackHosting"].buttons["BeSocial"]
        besocialButton.tap()
                        
    }
}
