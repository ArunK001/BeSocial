//
//  FeedViewModelTests.swift
//  BeSocialTests
//
//  Created by Arun Pattanayak on 04/12/24.
//

import Testing
@testable import BeSocial

struct FeedViewModelTests  {
    @Test func testFetchPostSuccess() async throws {
        let mockService: MockPostService  = MockPostService()
        let viewModel: MockFeedViewModel = MockFeedViewModel(networkManager: mockService)
        
        // Arrange
        mockService.shouldReturnError = false

        viewModel.fetchPost()

        Task {
            try? await Task.sleep(nanoseconds: 1 * 1_000_000_000)

            
            // Assert
            #expect(viewModel.isLoading)
            #expect(viewModel.errorMessage.isEmpty)
            #expect(viewModel.posts.count == 0)
            #expect(viewModel.posts.first?.user == "john_doe")
        }
    }

    @Test func testFetchPostFailure() async throws {
        let mockService: MockPostService  = MockPostService()
        let viewModel: MockFeedViewModel = MockFeedViewModel(networkManager: mockService)
        
        // Arrange
        mockService.shouldReturnError = true

        viewModel.fetchPost()

        // Assert
        #expect(viewModel.isLoading)
        #expect(viewModel.errorMessage.isEmpty)
        #expect(viewModel.posts.count == 0)
    }

    @Test func testLoadingStateDuringFetch() async throws {
        let mockService: MockPostService  = MockPostService()
        let viewModel: FeedViewModel = FeedViewModel(networkManager: mockService)
        
        mockService.shouldReturnError = false

        viewModel.fetchPost()

        #expect(viewModel.isLoading)
    }
}
