//
//  PostModelTests.swift
//  BeSocialTests
//
//  Created by Arun Pattanayak on 04/12/24.
//

import Testing
import Foundation
@testable import BeSocial

struct PostModelTests {

    @Test("Posts with right data") func testPostDecoding() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
        let postString = """
        [{
            "user": "charlotte_james",
            "photos": [
              "https://unsplash.com/photos/an-aerial-view-of-a-body-of-water-hWBU3vMpTkg",
              "https://unsplash.com/photos/blue-net-IV--3UEiHlI"
            ],
            "title": "Ocean vibes",
            "likes": 235,
            "comments": [
              {
                "comment": "This is so calming.",
                "likes": 60
              },
              {
                "comment": "I can listen to the ocean.",
                "likes": 40
              },
              {
                "comment": "Perfectly captured!",
                "likes": 30
              }
            ],
            "following": true
          }]
        """

        guard let postData = postString.data(using: .utf8) else {
            #expect(Bool(false))
            return
        }

        do {
            let posts = try decodePosts(from: postData)

            #expect(posts.isEmpty == false)

            let firstPost = posts.first
            #expect(firstPost?.following == true)
            #expect(firstPost?.comments.count == 3)
            #expect(firstPost?.likes == 235)
            #expect(firstPost?.comments.first?.comment == "This is so calming.")
            #expect(firstPost?.comments.first?.likes == 60)
            #expect(firstPost?.photos.count == 2)
            #expect(firstPost?.photos.firstIndex(of: "https://unsplash.com/photos/blue-net-IV--3UEiHlI") == 1)
        }
        catch {
            #expect(error == nil)
        }
    }

    @Test("Post with Missing field",.tags(.WrongData.missingField)) func testPostDecodingFail() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
        let postString = """
        [{
            "photos": [
              "https://unsplash.com/photos/an-aerial-view-of-a-body-of-water-hWBU3vMpTkg",
              "https://unsplash.com/photos/blue-net-IV--3UEiHlI"
            ],
            "title": "Ocean vibes",
            "likes": "235",
            "comments": [
              {
                "comment": "This is so calming.",
                "likes": "60"
              },
              {
                "comment": "I can listen to the ocean.",
                "likes": "40"
              },
              {
                "comment": "Perfectly captured!",
                "likes": "30"
              }
            ],
            "following": true
          }]
        """

        guard let postData = postString.data(using: .utf8) else {
            #expect(Bool(true))
            return
        }

        do {
            let posts = try decodePosts(from: postData)

            #expect(posts.isEmpty == true)
        }
        catch {
            #expect(error != nil)
        }
    }

    private func decodePosts(from jsonData: Data) throws -> [Feed] {
        let decoder = JSONDecoder()
        return try decoder.decode([Feed].self, from: jsonData)
    }

}

extension Tag {
    enum WrongData {}
}

extension Tag.WrongData {
    @Tag static var missingField: Tag
}
