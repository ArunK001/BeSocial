//
//  MockPostService.swift
//  BeSocialTests
//
//  Created by Arun Pattanayak on 04/12/24.
//

import Testing
import Foundation
@testable import BeSocial

final class MockPostService: PostServiceProtocol {
    var shouldReturnError = false

    func fetchPost(endpoint: String) async throws -> Result<[Feed], NetworkError> {
        if shouldReturnError {
            return .failure(NetworkError.unknown)
        }

        let mockFeed = Feed(
            user: "john_doe",
            photos: [
                "https://images.unsplash.com/photo-1609741199695-096c491c7ccc?q=80&w=3027&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
                "https://images.unsplash.com/photo-1609741199695-096c491c7ccc?q=80&w=3027&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
            ],
            title: "Exploring the mountains ൾ 🌄",
            likes: 154,
            comments: [
                Comment(comment: "Amazing view!", likes: 32),
                Comment(comment: "Wish I was there.", likes: 25),
                Comment(comment: "This place looks surreal.", likes: 19)
            ],
            geoTag: GeoTag(
                latitude: 37.7749,
                longitude: -122.4194,
                location: "San Francisco, CA"
            ),
            following: false
        )
        return .success([mockFeed])
    }
}
