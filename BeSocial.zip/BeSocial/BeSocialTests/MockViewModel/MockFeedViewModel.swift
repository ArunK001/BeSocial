//
//  MockFeedViewModel.swift
//  BeSocialTests
//
//  Created by Arun Pattanayak on 04/12/24.
//

import Foundation
@testable import BeSocial

final class MockFeedViewModel: FeedViewModelProtocol {
    var posts: [Feed] = []
    var errorMessage: String = ""
    var isLoading: Bool = false
    
    // Simulated response configurations
    var shouldReturnError = false
    var mockPosts: [Feed] = []
    var mockErrorMessage: String = "Mock error occurred"
    
    private let networkManager: MockPostService
    
    init(networkManager: PostServiceProtocol) {
        self.networkManager = networkManager as! MockPostService
    }
    
    func fetchPost() {
        isLoading = true
        
        Task {
            let result = try await networkManager.fetchPost(endpoint: "")
            
            switch result {
            case .success(let feeds):
                self.mockPosts = feeds
            case .failure(let err):
                self.errorMessage = err.localizedDescription
            }
            
            // Simulate asynchronous behavior
            if self.shouldReturnError {
                self.errorMessage = self.mockErrorMessage
                self.posts = []
            } else {
                self.posts = self.mockPosts
                self.errorMessage = ""
            }
            self.isLoading = false
        }
    }
}
