//
//  BeSocialTests.swift
//  BeSocialTests
//
//  Created by Arun Pattanayak on 04/12/24.
//

import Testing
@testable import BeSocial

struct BeSocialTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
